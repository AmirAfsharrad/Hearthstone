package GameLogic.Interfaces;

public interface Attacker {
    void attack(Attackable target, int attackValue);
}
