package GameLogic.Interfaces;

import UserHandle.Contestant;

public interface Target {
    Contestant getContestant();
    String getName();
}
