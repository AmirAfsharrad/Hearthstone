package GameLogic.Interfaces;

public interface Attackable {
    void acceptAttack(int attackValue);
}
