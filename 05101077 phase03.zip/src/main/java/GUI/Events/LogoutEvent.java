package GUI.Events;

import java.util.EventObject;

public class LogoutEvent extends EventObject {
    public LogoutEvent(Object source) {
        super(source);
    }
}
