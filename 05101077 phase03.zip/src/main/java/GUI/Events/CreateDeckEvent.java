package GUI.Events;

import java.util.EventObject;

public class CreateDeckEvent extends EventObject {
    public CreateDeckEvent(Object source) {
        super(source);
    }
}
