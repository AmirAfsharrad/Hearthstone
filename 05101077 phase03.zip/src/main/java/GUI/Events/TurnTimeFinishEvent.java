package GUI.Events;

import java.util.EventObject;

public class TurnTimeFinishEvent extends EventObject {

    public TurnTimeFinishEvent(Object source) {
        super(source);
    }


}
