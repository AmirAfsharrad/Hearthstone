package GameHandler;

public enum ContestantState {
    Normal, waitingForTarget;
}
