package UserHandle;

import Cards.*;
import GameHandler.ContestantState;
import GameHandler.GameHandler;
import GameHandler.GameState;
import GameLogic.Interfaces.*;
import GameLogic.PlayCards;
import GameLogic.Visitors.DealDamageVisitor;
import GameLogic.Visitors.GiveHealthVisitor;
import GameLogic.Visitors.ModifyAttackVisitor;
import Heroes.Hero;
import Heroes.Mage;
import Heroes.Paladin;
import Heroes.Rogue;
import Logger.Logger;
import Places.Playground;
import Utilities.DeckReader;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class Contestant {
    private String name;
    private ArrayList<Card> planted;
    private ArrayList<Card> hand;
    private ArrayList<Card> deck;
    private Hero hero;
    private Weapon currentWeapon;
    private Spell currentSpell;
    private Card choiceOfWeapon;
    private boolean hasWeapon;
    private boolean freePower;
    private boolean hasNurse;
    private boolean waitingForTarget;
    private int mana;
    private int turnFullManas;
    private String passive;
    private boolean drawTwice;
    private ContestantState state = ContestantState.Normal;
    private Target target;
    private boolean[] initialHandModificationCheck = new boolean[3];
    private boolean immuneHero;
    private Quest activeQuest;
    private int heroPowerNumber;

    public Contestant(String name) {
        this.name = name;
        passive = "";
    }

    public Target getTarget() {
        return target;
    }

    public void setTarget(Target target) {
        this.target = target;
    }

    public void init(Deck inputDeck) {
        initDeck(inputDeck);
        initHero(inputDeck);
        mana = 1;
        turnFullManas = 1;
        planted = new ArrayList<>();
        hand = new ArrayList<>();
        initHand();
        drawTwice = false;
        initPassiveProcess();
    }

    private void initDeck(Deck inputDeck) {
        deck = new ArrayList<>();
        for (Card card : inputDeck.getCards()) {
            deck.add(card.clone());
        }
        for (Card card : deck) {
            card.setContestant(this);
        }
    }

    private void initHero(Deck inputDeck) {
        hero = inputDeck.getHero();
        hero.setContestant(this);
    }

    private void initHand() {
        int count = 0;
//        for (Card card : deck) {
//            if (card.getType().equals("Quest")) {
//                if (count < 3) {
//                    hand.add(card);
//                    deck.remove(card);
//                    count++;
//                }
//            }
//        }
        for (int i = 0; i < Math.min(3 - count, deck.size()); i++) {
            if (DeckReader.getInstance().isActive()) {
                deck.get(0).setContestant(this);
                hand.add(deck.get(0));
                deck.remove(0);
            } else {
                hand.add(popRandomCard(deck));
            }
        }
    }

    public void initPassiveProcess() {
        switch (passive) {
            case "off cards": {
                for (Card card : deck) {
                    card.setMana(Math.max(0, card.getMana() - 1));
                }
                for (Card card : hand) {
                    card.setMana(Math.max(0, card.getMana() - 1));
                }
                break;
            }
            case "mana jump": {
                mana = 2;
                turnFullManas = 2;
                break;
            }
            case "draw twice": {
                drawTwice = true;
                break;
            }
            case "free power": {
                freePower = true;
                break;
            }
            case "nurse": {
                hasNurse = true;
                break;
            }
        }
    }


    public void drawRandomCard(boolean noSpell) {
        if (hand.size() < 12) {
            if (deck.size() > 0) {
                Card card;
                if (DeckReader.getInstance().isActive()) {
                    card = deck.get(0);
                    deck.remove(0);
                } else {
                    card = popRandomCard(deck);
                }

                drawEffectHandle(card);
                if (!card.getType().equals("Spell") || !noSpell)
                    hand.add(card);
            }
        }
    }

    private void drawEffectHandle(Card card) {
        for (Card card1 : planted) {
            Minion minion = (Minion) card1;
            if (card instanceof Minion) {
                ((Minion) card).setAttackPower(((Minion) card).getAttackPower() + minion.getDrawEffect()[0]);
                ((Minion) card).setHp(((Minion) card).getHp() + minion.getDrawEffect()[1]);
            }
            if (card instanceof Weapon) {
                ((Weapon) card).setAttackPower(((Weapon) card).getAttackPower() + minion.getDrawEffect()[0]);
                ((Weapon) card).setDurability(((Weapon) card).getDurability() + minion.getDrawEffect()[1]);
            }
            card.setMana(card.getMana() + minion.getDrawEffect()[2]);
        }
    }

    public void startTurn() throws IOException {
        state = ContestantState.Normal;
        Logger.log("Start turn", "start of " + name + "'s turn");
        mana = Math.min(turnFullManas + 1, 10);
        turnFullManas = mana;
        currentSpell = null;
        if (currentWeapon != null)
            currentWeapon.setTurnAttack(1);
        drawRandomCard(false);
        if (drawTwice) {
            drawRandomCard(false);
        }
        if (hero instanceof Rogue && currentWeapon != null) {
            ((Rogue) hero).setUpgradedHeroPower(true);
        }
        plantedAttackValuesInitiate();
        startTurnMinionEffectHandle();
        startTurnWeaponEffectHandle();
        if (hero instanceof Rogue) {
            ((Rogue) hero).initUpgradedHeroPower();
        }
        checkForDeadMinions();
        initHeroPowerNumber();
        Playground.getPlayground().getOpponentContestant().checkForDeadMinions();
    }


    private void initHeroPowerNumber() {
        if (freePower)
            heroPowerNumber = 2;
        else
            heroPowerNumber = 1;
    }

    private void startTurnMinionEffectHandle() throws IOException {
        for (Card card : planted) {
            Minion minion = (Minion) card;
            if (minion.getTurnStartDamage()[0] > 0) {
                for (Card card1 : Playground.getPlayground().getOpponentContestant().getPlanted()) {
                    ((Minion) card1).acceptDamage(DealDamageVisitor.getInstance(), minion.getTurnStartDamage()[0]);
                }
            }
        }
        checkForDeadMinions();
        Playground.getPlayground().getOpponentContestant().checkForDeadMinions();
    }

    private void startTurnWeaponEffectHandle() throws IOException {
        if (currentWeapon != null && currentWeapon.getName().equals("Skull of the Man'ari")) {
            for (Card card : hand) {
                if (card.getName().equals("Sathrovarr")) {
                    safeRemove(hand, card);
                    summon(card);
                    break;
                }
            }
        }
    }

    private void plantedAttackValuesInitiate() {
        for (Card card : planted) {
            ((Minion) card).setJustPlanted(false);
            if (((Minion) card).isWindfury())
                ((Minion) card).setTurnAttack(2);
            else
                ((Minion) card).setTurnAttack(1);

            Minion minion = (Minion) card;
            System.out.println(minion + " , Taunt: " + minion.isTaunt() + " , Charge: " + minion.isCharge() +
                    " , Rush: " + minion.isRush());

        }
    }

    public void endTurn() throws IOException {
        Playground.getPlayground().checkForGameFinish();
        Logger.log("End turn", "end of " + name + "'s turn");
        immuneHero = false;
        waitingForTarget = false;
        if (currentWeapon != null && currentWeapon.getDurability() == 0) {
            currentWeapon = null;
            hasWeapon = false;
        }
        endTurnMinionEffectHandle();
        if (hero instanceof Paladin) {
            Minion minion = (Minion) getRandomCardFrom(planted, true);
            if (minion != null) {
                minion.acceptHealth(GiveHealthVisitor.getInstance(), 1, false, false);
                minion.acceptAttackModification(ModifyAttackVisitor.getInstance(), 1);
            }
        }
        if (hasNurse) {
            Minion minion = getDamagedMinion();
            if (minion != null) {
                minion.acceptHealth(GiveHealthVisitor.getInstance(),
                        100, false, true);
            }
        }
    }

    private void endTurnMinionEffectHandle() throws IOException {
        for (Card card : planted) {
            Minion minion = (Minion) card;
            if (minion.getTurnEndDamage()[0] > 0) {
                for (Card card1 : Playground.getPlayground().getOpponentContestant().getPlanted()) {
                    ((Minion) card1).acceptDamage(DealDamageVisitor.getInstance(), minion.getTurnEndDamage()[0]);
                }
            }
        }
        Playground.getPlayground().getOpponentContestant().checkForDeadMinions();
    }

    public void checkForDeadMinions() throws IOException {
        boolean flag = false;
        ArrayList<Integer> removedIndices = new ArrayList();
        for (int i = 0; i < planted.size(); i++) {
            if (((Minion) planted.get(i)).getHp() == 0) {
                if (((Minion) planted.get(i)).isReborn()) {
                    ((Minion) planted.get(i)).setReborn(false);
                    ((Minion) planted.get(i)).setHp(1);
                }
                removedIndices.add(0, i);
                flag = true;
            }
        }
        for (Integer removedIndex : removedIndices) {
            planted.remove((int) removedIndex);
        }
        if (flag) {
            GameState.getGameState().refreshMainFrame();
        }
    }

    private void spendMana(Card card) {
        if (card instanceof Spell && hero instanceof Mage) {
            mana -= (Math.max(card.getMana() - 2, 0));
        } else if (hero instanceof Rogue && !card.getHeroClass().equals("Rogue") && !card.getHeroClass().equals("Neutral")) {
            mana -= (Math.max(card.getMana() - 2, 0));
        } else {
            mana -= card.getMana();
        }

        if (activeQuest != null) {
            handleQuestCompletion(card);
        }
    }

    private void handleQuestCompletion(Card card) {
        switch (activeQuest.getName()) {
            case "Learn Draconic":
                if (card instanceof Spell) {
                    int completion = (int) Math.ceil(activeQuest.getCompletion() * 8.0 / 100);
                    completion = Math.min(8, completion + card.getMana());
                    activeQuest.setCompletion(completion * 100 / 8);
                    System.out.println("Quest completion = " + completion);
                    if (completion == 8) {
                        Minion minion = (Minion) GameHandler.getGameHandler().getCard("Viserion");
                        summon(minion);
                        activeQuest = null;
                    }
                }
                break;

            case "Strength in Numbers":
                if (card instanceof Minion) {
                    int completion = (int) Math.ceil(activeQuest.getCompletion() / 10);
                    completion = Math.min(10, completion + card.getMana());
                    activeQuest.setCompletion(completion * 10);
                    System.out.println("Quest completion = " + completion);
                    if (completion == 10) {
                        Minion minion = (Minion) getRandomCardFrom(deck, true);
                        if (DeckReader.getInstance().isActive()) {
                            minion = (Minion) DeckReader.getInstance().getQuestReward();
                        }
                        minion.setContestant(this);
                        if (minion != null) {
                            safeRemove(deck, minion);
                            summon(minion);
                        }
                        activeQuest = null;
                    }
                }
                break;
        }
    }

    private Card getRandomCardFrom(ArrayList<Card> cards, boolean getMinion) {
        ArrayList<Integer> indices = new ArrayList<>();
        int index = 0;
        for (Card card : cards) {
            if (!getMinion || card instanceof Minion) {
                indices.add(index);
            }
            index++;
        }
        Random random = new Random();
        if (indices.size() > 0) {
            index = random.nextInt(indices.size());
            return cards.get(index);
        }
        return null;
    }

    private Minion getDamagedMinion() {
        ArrayList<Integer> indices = new ArrayList<>();
        int index = 0;
        for (Card card : planted) {
            if (((Minion) card).getHp() < ((Minion) card).getOriginalHp()) {
                indices.add(index);
            }
            index++;
        }
        Random random = new Random();
        if (indices.size() > 0) {
            index = random.nextInt(indices.size());
            return (Minion) planted.get(index);
        }
        return null;
    }

    public void playCard(Card card, int numberOnLeft) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (card.getMana() <= mana) {
                    waitingForTarget = false;
                    safeRemove(hand, card);
                    spendMana(card);
                    Logger.log("Card Played", card.getName());
                    switch (card.getType()) {
                        case "Minion":
                            PlayCards.playMinion(card, numberOnLeft);
                            break;
                        case "Weapon":
                            PlayCards.playWeapon((Weapon) card);
                            break;
                        case "Spell":
                            try {
                                PlayCards.playSpell((Spell) card);
                            } catch (IOException | InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case "Quest":
                            PlayCards.playQuest((Quest) card);
                            break;
                    }
//                    checkForDeadMinions();
                    Playground.getPlayground().getGameLog().add(name + ": " + card);
                }
            }
        }).start();
    }

    public void runHeroPower() throws IOException {
        int heroPowerCost = freePower ? 1 : 2;
        if (heroPowerNumber == 0)
            return;

        if (mana < heroPowerCost)
            return;

        heroPowerNumber--;
        mana -= heroPowerCost;

        switch (hero.getType()) {
            case "Mage":
                waitingForTarget = true;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Contestant contestant = Playground.getPlayground().getCurrentContestant();
                        Contestant opponentContestant = Playground.getPlayground().getOpponentContestant();
                        Object target = null;

                        System.out.println("WAITING for attack target");

                        while (contestant.getTarget() == null || contestant.getTarget().getContestant() == contestant) {
                            try {
                                Thread.sleep(50);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.println("target received");
                        System.out.println("target = " + contestant.getTarget().getName());
                        target = contestant.getTarget();
                        contestant.setTarget(null);
                        contestant.setWaitingForTarget(false);
                        if (!(target instanceof Minion && ((Minion) target).isStealth())
                                && !(target instanceof Minion && ((Minion) target).getContestant() == contestant)
                                && !(target instanceof Hero && target == contestant.getHero())) {
                            ((Damageable) target).acceptDamage(DealDamageVisitor.getInstance(), 2);
                        }
                        try {
                            contestant.checkForDeadMinions();
                            opponentContestant.checkForDeadMinions();
                            GameState.getGameState().refreshMainFrame();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;

            case "Rogue":
                if (mana > 0) {
                    mana--;
                } else {
                    mana += 2;
                    break;
                }
                Card card = getRandomCardFrom(Playground.getPlayground().getOpponentContestant().getDeck(), false);
                if (card != null) {
                    safeRemove(Playground.getPlayground().getOpponentContestant().getDeck(), card);
                    card.setContestant(this);
                    deck.add(card);
                }
                if (((Rogue) hero).isUpgradedHeroPower()) {
                    card = getRandomCardFrom(Playground.getPlayground().getOpponentContestant().getHand(), false);
                    if (card != null) {
                        safeRemove(Playground.getPlayground().getOpponentContestant().getHand(), card);
                        card.setContestant(this);
                        hand.add(card);
                    }
                }
                break;

            case "Warlock":
                Random random = new Random();
                hero.setHp(Math.max(hero.getHp() - 2, 0));
                Playground.getPlayground().checkForGameFinish();
                int rand = random.nextInt(2);
                if (rand == 1) {
                    Minion minion = (Minion) getRandomCardFrom(planted, true);
                    if (minion != null) {
                        minion.setHp(minion.getHp() + 1);
                        minion.setAttackPower(minion.getAttackPower() + 1);
                    }
                } else {
                    drawRandomCard(false);
                }
                break;

            case "Paladin":
                for (int i = 0; i < 2; i++) {
                    Minion minion = (Minion) GameHandler.getGameHandler().getCard("Silver Hand Recruit");
                    minion.setContestant(this);
                    summon(minion);
                }
                break;

            case "Priest":
                waitingForTarget = true;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Contestant contestant = Playground.getPlayground().getCurrentContestant();
                        Object target = null;

                        System.out.println("WAITING for attack target");

                        while (contestant.getTarget() == null || contestant.getTarget().getContestant() != contestant) {
                            try {
                                Thread.sleep(50);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.println("target received");
                        System.out.println("target = " + contestant.getTarget().getName());
                        target = contestant.getTarget();
                        contestant.setTarget(null);
                        contestant.setWaitingForTarget(false);

                        ((HealthTaker) target).acceptHealth(GiveHealthVisitor.getInstance(),
                                4, false, true);
                    }
                }).start();
                break;
        }
        GameState.getGameState().refreshMainFrame();
    }


    public void initiateAttack(Attacker attacker, int attackValue) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Contestant contestant = Playground.getPlayground().getCurrentContestant();
                Contestant opponentContestant = Playground.getPlayground().getOpponentContestant();
                Object target = null;

                System.out.println("WAITING for attack target");

                while (contestant.getTarget() == null || contestant.getTarget().getContestant() == contestant) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("target received");
                System.out.println("target = " + contestant.getTarget().getName());
                target = contestant.getTarget();
                contestant.setTarget(null);
                contestant.setWaitingForTarget(false);
                if ((!opponentContestant.hasTaunt() || (target instanceof Minion && ((Minion) target).isTaunt()))
                        && !(target instanceof Minion && ((Minion) target).isStealth())
                        && !((target instanceof Hero) && attacker instanceof Minion &&
                        ((Minion) attacker).isRush() && ((Minion) attacker).isJustPlanted())) {
                    attacker.attack((Attackable) target, attackValue);
                    if (attacker instanceof Minion && ((Minion) attacker).isPoisonous() && target instanceof Card) {
                        safeRemove(opponentContestant.getDeck(), (Card) target);
                    }
                }
                try {
                    contestant.checkForDeadMinions();
                    opponentContestant.checkForDeadMinions();
                    GameState.getGameState().refreshMainFrame();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public int getNewPlantedCardIndex(int numberOnLeft) {
        int maxSize;
        if (planted.size() % 2 == 0) {
            maxSize = 6;
        } else {
            maxSize = 7;
        }
        return Math.min(Math.max(numberOnLeft - (maxSize - planted.size()) / 2, 0), planted.size());
    }

    private Card popRandomCard(ArrayList<Card> cards) {
        if (!cards.isEmpty()) {
            Random random = new Random();
            int rand = random.nextInt(cards.size());
            Card randomCard = cards.get(rand);
            cards.remove(rand);
            return randomCard;
        } else {
            return null;
        }
    }

    public void initialHandModification(Card card) throws IOException {
        if (deck.size() <= 3)
            return;
        int index = 0;
        for (int i = 0; i < 3; i++) {
            if (hand.get(i) == card) {
                index = i;
                break;
            }
        }
        if (!initialHandModificationCheck[index]) {
            initialHandModificationCheck[index] = true;
            hand.remove(index);
            Card newCard = card;
            while (newCard == card) {
                newCard = popRandomCard(deck);
            }
            hand.add(index, newCard);
            GameState.getGameState().refreshMainFrame();
        }
    }


    public int getRemainingDeckSize() {
        return deck.size();
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getTurnFullManas() {
        return turnFullManas;
    }

    public void setTurnFullManas(int turnFullManas) {
        this.turnFullManas = turnFullManas;
    }

    public ArrayList<Card> getPlanted() {
        return planted;
    }

    public void setPlanted(ArrayList<Card> planted) {
        this.planted = planted;
    }

    public ArrayList<Card> getHand() {
        return hand;
    }

    public void setHand(ArrayList<Card> hand) {
        this.hand = hand;
    }

    public Hero getHero() {
        return hero;
    }

    public void setHero(Hero hero) {
        this.hero = hero;
    }

    public Weapon getCurrentWeapon() {
        return currentWeapon;
    }

    public void setCurrentWeapon(Weapon currentWeapon) {
        this.currentWeapon = currentWeapon;
    }

    public boolean hasWeapon() {
        return hasWeapon;
    }

    public boolean isWaitingForTarget() {
        return waitingForTarget;
    }

    public void setWaitingForTarget(boolean waitingForTarget) {
        if (waitingForTarget)
            state = ContestantState.waitingForTarget;
        else
            state = ContestantState.Normal;
        this.waitingForTarget = waitingForTarget;
    }

    public Spell getCurrentSpell() {
        return currentSpell;
    }

    public void setCurrentSpell(Spell currentSpell) {
        this.currentSpell = currentSpell;
    }

    public ContestantState getState() {
        return state;
    }

    public void setState(ContestantState state) {
        this.state = state;
    }

    public boolean hasTaunt() {
        for (Card card : planted) {
            if (((Minion) card).isTaunt())
                return true;
        }
        return false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Quest getActiveQuest() {
        return activeQuest;
    }

    public void setActiveQuest(Quest activeQuest) {
        this.activeQuest = activeQuest;
    }

    public ArrayList<Card> getDeck() {
        return deck;
    }

    public void setDeck(ArrayList<Card> deck) {
        this.deck = deck;
    }

    public boolean isHasWeapon() {
        return hasWeapon;
    }

    public void setHasWeapon(boolean hasWeapon) {
        this.hasWeapon = hasWeapon;
    }

    public String getPassive() {
        return passive;
    }

    public void setPassive(String passive) {
        this.passive = passive;
    }

    public boolean isDrawTwice() {
        return drawTwice;
    }

    public void setDrawTwice(boolean drawTwice) {
        this.drawTwice = drawTwice;
    }

    public Card getChoiceOfWeapon() {
        return choiceOfWeapon;
    }

    public void setChoiceOfWeapon(Card choiceOfWeapon) {
        this.choiceOfWeapon = choiceOfWeapon;
    }

    public <T> void safeRemove(ArrayList<T> arrayList, T item) {
        int index;
        boolean flag;
        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i) == item) {
                arrayList.remove(i);
                break;
            }
        }
    }

    public boolean isImmuneHero() {
        return immuneHero;
    }

    public void setImmuneHero(boolean immuneHero) {
        this.immuneHero = immuneHero;
    }

    public int getPlantedCardIndex(Card card) {
        for (int i = 0; i < planted.size(); i++) {
            if (card == planted.get(i)) {
                return i;
            }
        }
        return -1;
    }

    public ArrayList<Card> getListOfWeapons() {
        ArrayList<Card> weapons = GameHandler.getGameHandler().getWeapons();
        int number = weapons.size();
        Random random = new Random();
        HashSet<Integer> numbers = new HashSet<>();
        while (numbers.size() < 3) {
            numbers.add(random.nextInt(number));
        }
        ArrayList<Card> result = new ArrayList<>();
        for (Integer integer : numbers) {
            result.add(weapons.get(integer));
        }
        return result;
    }

    public void summon(Card card) {
        if (planted.size() >= 7)
            return;
        for (Card card1 : planted) {
            if (card1.getName().equals("High Priest Amet")) {
                ((Minion) card).setHp(((Minion) card1).getHp());
            }
        }
        planted.add(card);
    }

    public void summon(int index, Card card) {
        if (planted.size() >= 7)
            return;
        for (Card card1 : planted) {
            if (card1.getName().equals("High Priest Amet")) {
                ((Minion) card).setHp(((Minion) card1).getHp());
            }
        }
        planted.add(index, card);
    }

    public Card hasPlantedCard(String cardName) {
        for (Card card : planted) {
            if (card.getName().equals(cardName))
                return card;
        }
        return null;
    }

}
