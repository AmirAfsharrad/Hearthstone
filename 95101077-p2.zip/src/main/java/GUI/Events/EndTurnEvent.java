package GUI.Events;

import java.util.EventObject;

public class EndTurnEvent extends EventObject {
    public EndTurnEvent(Object source) {
        super(source);
    }
}
